# Solinarium - Community Platform

## Overview

Solinarium is a full-stack web application designed to help families connect with each other in their local communities. The platform enables families to discover local communities, participate in events, and engage in community discussions. Built with modern web technologies, it provides a seamless experience for building meaningful connections between families.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ESM modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Authentication**: Replit's OpenID Connect integration with Passport.js
- **Session Management**: Express sessions with PostgreSQL store

### Database Schema
- **Users**: Profile information, location, family details
- **Communities**: Local family groups organized by city
- **Events**: Community events with location and attendance tracking
- **Messages**: Community chat functionality
- **Join Tables**: Community memberships and event attendance

## Key Components

### Authentication System
- **OpenID Connect**: Integration with Replit's authentication system
- **Session Management**: Persistent sessions stored in PostgreSQL
- **User Profile Management**: Comprehensive profile system with family information
- **Authorization**: Route-level protection for authenticated users

### Community Features
- **Community Discovery**: Browse communities by city
- **Community Creation**: Users can create new local communities
- **Membership Management**: Join/leave community functionality
- **Community Chat**: Real-time messaging within communities

### Event System
- **Event Discovery**: Browse local events by city
- **Event Creation**: Community members can organize events
- **RSVP System**: Track event attendance
- **Event Details**: Comprehensive event information with date, time, and location

### User Interface
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Component System**: Reusable UI components based on Radix UI
- **Dark Mode Ready**: CSS variables setup for theme switching
- **Accessibility**: ARIA-compliant components from Radix UI

## Data Flow

### User Authentication Flow
1. User accesses protected route
2. Middleware checks for valid session
3. If unauthenticated, redirects to Replit OAuth
4. After successful authentication, user data is stored/updated
5. Session is created and user is redirected to application

### Community Interaction Flow
1. User browses communities filtered by their city
2. User joins communities of interest
3. User can view community-specific chat messages
4. User can create new events within communities
5. Other community members can RSVP to events

### Data Fetching Strategy
- **TanStack Query**: Handles all server state with caching and background updates
- **API Routes**: RESTful endpoints for all data operations
- **Error Handling**: Comprehensive error handling with user feedback
- **Real-time Updates**: Polling for chat messages (5-second intervals)

## External Dependencies

### Authentication & Database
- **Replit Auth**: OpenID Connect provider for user authentication
- **Neon Database**: Serverless PostgreSQL database hosting
- **Drizzle ORM**: Type-safe database queries and migrations

### UI & Development
- **Radix UI**: Accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide Icons**: Consistent icon library
- **Date-fns**: Date manipulation and formatting

### Development Tools
- **Vite**: Fast build tool with HMR
- **TypeScript**: Static type checking
- **ESBuild**: Fast JavaScript bundler for production

## Deployment Strategy

### Development Environment
- **Replit Integration**: Optimized for Replit development environment
- **Hot Module Replacement**: Instant updates during development
- **Development Banner**: Replit-specific development indicators

### Production Build
- **Client Build**: Vite builds React application to `dist/public`
- **Server Build**: ESBuild bundles Express server to `dist/index.js`
- **Static Assets**: Served from built client application
- **Database Migrations**: Drizzle handles schema changes

### Environment Configuration
- **Database URL**: PostgreSQL connection string
- **Session Secret**: Secure session encryption key
- **Replit Integration**: Domain and authentication configuration

## Changelog

```
Changelog:
- July 02, 2025. Initial setup
- July 02, 2025. Updated to allow public viewing of communities and events without authentication
  - Users can now browse communities and events on landing page and dedicated pages
  - Interactive features (joining, chatting, creating) still require authentication
  - Added public navigation headers for non-authenticated users
- July 02, 2025. Added dummy data for testing and demonstration
  - Populated database with 50 families from 25 cities worldwide
  - Created 10 communities across major cities (London, Madrid, Paris, Berlin, Tokyo, NYC, Sydney, Toronto, São Paulo, Amsterdam)
  - Added 20 events with realistic family-friendly activities
  - All dummy data marked with isDummy: true flag for easy removal via scripts/remove-dummy-data.ts
- July 02, 2025. Transformed into mobile-first application
  - Added bottom navigation menu for mobile devices
  - Implemented responsive design across all pages and components
  - Added social proof avatars in hero section with family images
  - Created authentication popup with social media login options (Google, Apple, Facebook, GitHub)
  - Optimized typography, spacing, and layout for mobile viewing
- July 02, 2025. Rebranded application to Solinarium
  - Updated all references from "FamilyConnect" to "Solinarium" throughout the application
  - Added Awakened Soul Ventures LLC attribution in footer
  - Updated page title and meta description to reflect new branding
- July 02, 2025. Restructured navigation to 3-item mobile-first design
  - Simplified navigation to Home, Chat, Profile (as requested)
  - Moved Families, Communities, Events from navigation to tabs within Home page
  - Created Telegram-style Chat page with 4 tabs (People, Cities, Communities, Events)
  - Fixed dark theme with proper black/white contrast throughout application
  - Fixed API endpoint mismatches between client and server for settings/profile/avatar updates
  - Added profile completion requirements for chat access (name + city required)
- July 02, 2025. Enhanced user experience with advanced features
  - Added city field geolocation and autocomplete with 40+ popular cities worldwide
  - Implemented browser geolocation API with reverse geocoding for automatic city detection
  - Enhanced toast notifications to auto-dismiss in 2 seconds for better UX
  - Upgraded avatar upload to support file upload with preview and 5MB size limit
  - Added profile completion checks for joining communities/events
  - Implemented automatic redirect to chat after joining communities/events (when profile complete)
  - Improved form validation and error handling throughout profile management
- July 02, 2025. Enhanced UI consistency and mobile experience improvements
  - Implemented persistent city selection using CityContext with localStorage across all screens  
  - Enhanced city selection with custom city addition and Enter key support
  - Updated Chat screen to filter content based on cities selected in Home/Profile screens
  - Removed tab icons from Chat screen for cleaner mobile design
  - Changed "Join Chat" buttons to "Chat" and moved to bottom of cards for better spacing
  - Fixed Communities tab icon in Home screen to use MessageCircle for consistency
  - Made all tab icons consistent size (w-4 h-4) across all screens
- July 02, 2025. Enhanced city selection and discovery features
  - Added ability to remove the last selected city to show all locations (displays "Show All")
  - Implemented "Show in other cities" clickable links at bottom of each Home tab
  - Added translations for "showInOtherCities" and "showAll" in all supported languages
  - Links open city settings dialog to allow users to expand their location selection
- July 03, 2025. Improved UI consistency and Schools page performance
  - Standardized city badge design across all screens (Home, Chat, Schools) using Badge component
  - Removed background from Home screen for consistent header styling
  - Added city settings popup dialog to Schools page (no redirect to profile)
  - Implemented Schools page pagination with skeleton loading (10 schools per page)
  - Added "Load More" button showing remaining school count
  - Reset pagination when search/filter criteria change
  - All city badges now show selected cities count and sync with CityContext
- July 03, 2025. Fixed header positioning and navigation styling issues
  - Fixed Schools page header positioning to match other screens (changed from py-8 to p-4)
  - Updated Profile page Settings button to use Badge component matching Home page city badge style
  - Enhanced bottom navigation with proper active/inactive states (gray for inactive, orange for active)
  - Eliminated all full-page loading screens, replaced with targeted skeleton loading for better UX
  - Hidden scrollbar visibility throughout application while maintaining scroll functionality
- July 03, 2025. Standardized city badge component and corrected "View all" button placement
  - Created reusable CityBadge component for consistent behavior across Home, Schools, and Chat screens
  - Fixed "View all" button placement - now only appears in Home "All" tab for Communities/Events horizontal scrolls
  - Removed incorrect "View all" buttons from individual tab pages (Families, Communities, Events tabs)
  - "View all" links now properly navigate between tabs when there are more than 6 items to display
  - Ensured consistent city selection dialog and removal functionality across all screens
  - Fixed duplicate Create button issue in Schools screen - header Create button now hidden when showing empty state
- July 05, 2025. Major improvements to app functionality and real data integration
  - Fixed Chat screen profile completion check to recognize city selection from CityContext
  - Added Notifications section before Settings in Profile screen with proper Bell icon
  - Added "Show in other cities" link to Schools page for consistent navigation pattern
  - Replaced all fake/dummy schools with 10 real alternative education institutions:
    * Maria Montessori School (London), Rudolf Steiner School (Stuttgart)
    * Sudbury Valley School (Framingham), Summerhill School (Suffolk)
    * Highland Hall Waldorf School (Los Angeles), Montessori School of Denver
    * Greenwood Tree Educational Cooperative (Burlington), Secret Garden Outdoor Nursery (Edinburgh)
    * Cedarsong Nature School (Vashon Island), Steiner Academy Bristol
  - All schools now feature authentic data including real websites, contact information, and educational approaches
  - Fixed profile screen display: removed quantity numbers, changed to "My Communities/Events", updated empty state messages
- July 07, 2025. Mobile deployment setup completed with Capacitor and Firebase push notifications
  - Installed Capacitor core packages and push notification dependencies
  - Added Firebase integration for web and mobile push notifications
  - Created Capacitor configuration for Android and iOS platforms with correct package name (com.awakenedsoul.solinarium)
  - Set up push notification database schema with push_tokens table and API endpoints
  - Added Android and iOS native platforms for mobile app building
  - Created app icons and PWA manifest for mobile deployment
  - Configured Firebase project (solinariumcom) with google-services.json for Android
  - Fixed TypeScript compilation errors in storage.ts and routes.ts for production build
  - Created comprehensive mobile deployment documentation (MOBILE_DEPLOYMENT.md)
  - App is now ready for Google Play Store and Apple App Store submission
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```