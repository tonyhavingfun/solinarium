
package com.awakenedsoul.solinarium;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
